﻿using System;
using System.Collections.Generic;

namespace DCRM.Common.Entity;

public class Patientse
{
    public int Id { get; set; } 

    public string Chamber_Id { get; set; }

    public int User_Id { get; set; }

    public string Mr_Number { get; set; } 

    public string? Name { get; set; }

    public string? UserName { get; set; }

    public string? Slug { get; set; }

    public string? Thumb { get; set; }

    public string? Email { get; set; }

    public sbyte? Age { get; set; }

    public int? Weight { get; set; }

    public string? Sex { get; set; }

    public string? Mobile { get; set; }

    public string? Password { get; set; }

    public string? Title { get; set; }

    public string? Guardian { get; set; }

    public string? Role { get; set; }

    public string? Verify_Code { get; set; }

    public string? Present_Address { get; set; }

    public string? Permanent_Address { get; set; }

    public int Is_Delete { get; set; }

    public DateTime? Created_At { get; set; }
}
